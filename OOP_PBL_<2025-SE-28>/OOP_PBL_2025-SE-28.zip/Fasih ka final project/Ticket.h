#ifndef TICKET_H
#define TICKET_H

#include <iostream>
#include "Flight.h"
#include "Passenger.h"

using namespace std;

class Ticket
{
private:

    int ticketId;
    Flight* flight;
    Passenger* passenger;
    int seatNumber;
    double farePaid;
    bool active;

public:

    Ticket(
        int id       = 0,
        Flight* f    = NULL,
        Passenger* p = NULL,
        int seat     = 0,
        double fare  = 0.0
    );

    void display() const;

    int    getTicketId()   const;
    bool   isActive()      const;
    void   cancel();

    Flight*    getFlight()     const;
    Passenger* getPassenger()  const;
    double     getFarePaid()   const;
    int        getSeatNumber() const;

    bool operator==(const Ticket& other) const;
    friend ostream& operator<<(ostream& out, const Ticket& t);
};

#endif
